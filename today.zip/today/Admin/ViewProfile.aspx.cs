﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AppWebsite.Admin
{
    public partial class ViewProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Emp"]!= null)
            {
                List<Employee> LsEmpObj = new List<Employee>();
                Employee emp = new Employee();
                LsEmpObj = (List<Employee>)Session["Emp"];
                grdEmpView.DataSource = LsEmpObj;
                grdEmpView.DataBind();
                grdView2.DataSource = LsEmpObj;
                grdView2.DataBind();
                int[] empid = LsEmpObj.Select(x => x.EmpID).ToArray();
                grdView2.DataKeyNames = Array.ConvertAll(empid, x => x.ToString());
            }
        }
    }
}