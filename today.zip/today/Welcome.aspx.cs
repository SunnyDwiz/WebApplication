﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AppWebsite
{
    public partial class Welcome : System.Web.UI.Page
    {
        public static int empid =1;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            List<Employee> LsEmps = Session["Emp"]!=null?(List<Employee>)Session["Emp"]:new List<Employee>();
            Employee ObjEmp = LsEmps.Find(x => x.EmpName == txtUser.Text);

            if (ObjEmp == null)
            {
                ObjEmp = new Employee();
                ObjEmp.EmpID = empid;
                ObjEmp.EmpName = txtUser.Text;
                ObjEmp.Gender = DropDownList1.SelectedItem.Text;
                LsEmps.Add(ObjEmp);
                Session["Emp"] = LsEmps;
                empid += 1;
                Response.Write("<script>alert('Submitted Successfully');</script>");
            }
            else
            {
                Response.Write("<script> alert('User Name Not unique Insert Again!'); </script>");
            }
            
            Response.Redirect("/admin/ViewProfile.aspx");
        }
    }

    class Employee {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public string Gender { get; set; }
    }
}